package com.mygamestudio.nostaloomlauncher;

import android.app.Notification;
import android.app.NotificationManager;
import android.content.ComponentName;
import android.content.Context;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public final class NotificationFruitService extends NotificationListenerService {
    private static final SocialApp[] APPS = SocialApp.values();
    private static final List<Runnable> OBSERVERS = new ArrayList<>();
    private static final Snapshot UNAVAILABLE = new Snapshot(false);
    private static Snapshot snapshot = UNAVAILABLE;

    private final Handler main = new Handler(Looper.getMainLooper());
    private final Runnable refresh = this::publishActiveNotifications;
    private boolean connected;

    static final class Snapshot {
        final boolean ready;
        private final int[] counts = new int[APPS.length];
        private final String[] packages = new String[APPS.length];
        private final long[] latest = new long[APPS.length];

        Snapshot(boolean ready) {
            this.ready = ready;
        }

        int count(SocialApp app) {
            return counts[app.ordinal()];
        }

        String latestPackage(SocialApp app) {
            return packages[app.ordinal()];
        }

        private void add(SocialApp app, StatusBarNotification notification) {
            int index = app.ordinal();
            counts[index]++;
            if (notification.getPostTime() >= latest[index]) {
                latest[index] = notification.getPostTime();
                packages[index] = notification.getPackageName();
            }
        }
    }

    static boolean hasAccess(Context context) {
        ComponentName listener = new ComponentName(context, NotificationFruitService.class);
        if (Build.VERSION.SDK_INT >= 27) {
            return context.getSystemService(NotificationManager.class)
                .isNotificationListenerAccessGranted(listener);
        }
        String enabled = Settings.Secure.getString(
            context.getContentResolver(), "enabled_notification_listeners");
        if (enabled != null) {
            for (String entry : enabled.split(":")) {
                if (listener.equals(ComponentName.unflattenFromString(entry))) return true;
            }
        }
        return false;
    }

    static Snapshot current() {
        return snapshot;
    }

    static void observe(Runnable observer) {
        OBSERVERS.add(observer);
    }

    static void removeObserver(Runnable observer) {
        OBSERVERS.remove(observer);
    }

    @Override public void onListenerConnected() {
        main.post(() -> {
            connected = true;
            publishActiveNotifications();
        });
    }

    @Override public void onNotificationPosted(StatusBarNotification ignored) {
        queueRefresh();
    }

    @Override public void onNotificationRemoved(StatusBarNotification ignored) {
        queueRefresh();
    }

    @Override public void onListenerDisconnected() {
        main.post(this::disconnect);
    }

    @Override public void onDestroy() {
        main.removeCallbacksAndMessages(null);
        disconnect();
        super.onDestroy();
    }

    private void queueRefresh() {
        main.removeCallbacks(refresh);
        main.postDelayed(refresh, 85);
    }

    private void disconnect() {
        connected = false;
        main.removeCallbacks(refresh);
        publish(UNAVAILABLE);
    }

    private void publishActiveNotifications() {
        if (!connected) return;
        try {
            StatusBarNotification[] active = getActiveNotifications();
            publish(active == null ? UNAVAILABLE : countNotifications(active));
        } catch (SecurityException | IllegalStateException exception) {
            publish(UNAVAILABLE);
        }
    }

    static Snapshot countNotifications(StatusBarNotification[] active) {
        Snapshot result = new Snapshot(true);
        Set<String> groupsWithChildren = new HashSet<>();
        for (StatusBarNotification entry : active) {
            if (shouldCount(entry) && !isSummary(entry)) {
                groupsWithChildren.add(entry.getGroupKey());
            }
        }

        Set<String> countedKeys = new HashSet<>();
        for (StatusBarNotification entry : active) {
            if (!shouldCount(entry) || !countedKeys.add(entry.getKey())) continue;
            if (isSummary(entry) && groupsWithChildren.contains(entry.getGroupKey())) continue;
            result.add(SocialApp.fromPackage(entry.getPackageName()), entry);
        }
        return result;
    }

    private static boolean shouldCount(StatusBarNotification entry) {
        Notification notification = entry.getNotification();
        return SocialApp.fromPackage(entry.getPackageName()) != null
            && !entry.isOngoing()
            && (notification.flags & Notification.FLAG_FOREGROUND_SERVICE) == 0
            && !Notification.CATEGORY_TRANSPORT.equals(notification.category);
    }

    private static boolean isSummary(StatusBarNotification entry) {
        return (entry.getNotification().flags & Notification.FLAG_GROUP_SUMMARY) != 0;
    }

    private static void publish(Snapshot next) {
        Snapshot previous = snapshot;
        snapshot = next;
        if (next.ready != previous.ready || !Arrays.equals(next.counts, previous.counts)) {
            for (Runnable observer : new ArrayList<>(OBSERVERS)) observer.run();
        }
    }
}
