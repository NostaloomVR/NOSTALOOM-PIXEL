package com.mygamestudio.nostaloomlauncher;

import android.content.Context;
import android.graphics.Canvas;
import android.os.SystemClock;

final class MochiSpriteView extends PixelHomeView.ArtworkView {
    static final int WIDTH = 142;
    static final int HEIGHT = 76;

    private static final int INK = 0xff4b3147;
    private static final int CREAM = 0xffffedcf;
    private static final int GOLD = 0xffe3a371;
    private static final int PINK = 0xffed9c9c;
    private static final int LILAC = 0xff9772bc;
    private static final long IDLE_LOOP_MS = 11800;
    private static final float LEFT = 36;
    private static final float RIGHT = 105;
    private static final float GROUND = 67;

    private static final String[] HEAD = {
        "..##........##..",
        ".#aa#......#aa#.",
        ".#ap#......#pa#.",
        ".#apc######cp#.",
        ".#acaaaccccaa#.",
        "#aaaccccccaaaac#",
        "#aaacccccccaaac#",
        "#aacccccccccccc#",
        "#cccccccccccccc#",
        "#pcccccccccccp#.",
        ".#ccccccccccc#..",
        "..###########..."
    };

    private static final String[] SITTING_BODY = {
        "..######....",
        ".#cccaac#...",
        "#ccccaacc#..",
        "#cccacccc#..",
        "#accccccac#.",
        "#acccccccc#.",
        "#acccccccc#.",
        ".#########.."
    };

    private static final String[] WALKING_BODY = {
        "..#############..",
        ".#aaaaccccaaacc#.",
        "#aaaacccccaacccc#",
        "#aaacccccccccccc#",
        "#ccccccccccccccc#",
        ".###############."
    };

    private final Runnable frame = this::invalidate;
    private boolean running;
    private boolean faceRight = true;
    private float catX = 66;
    private float startX = catX;
    private long motionAt;
    private MochiCare.Action action;

    MochiSpriteView(Context context) {
        super(context, WIDTH, HEIGHT);
        setContentDescription("Belai Mochi. Tekan lama untuk menu kucing.");
    }

    void setRunning(boolean next) {
        if (running == next) return;
        running = next;
        if (next) {
            if (motionAt == 0) motionAt = SystemClock.uptimeMillis();
            invalidate();
        } else {
            removeCallbacks(frame);
        }
    }

    void begin(MochiCare.Action next) {
        action = next;
        motionAt = SystemClock.uptimeMillis();
        startX = catX;
        invalidate();
    }

    @Override void drawArtwork(Canvas canvas) {
        long now = SystemClock.uptimeMillis();
        long elapsed = motionAt == 0 ? 0 : Math.max(0, now - motionAt);
        if (action != null && elapsed >= actionDuration(action)) {
            action = null;
            motionAt = now;
            startX = catX;
            elapsed = 0;
        }

        float previousX = catX;
        boolean walking = false;
        boolean eating = false;
        boolean asleep = action == MochiCare.Action.REST;
        float hop = 0;
        if (action == MochiCare.Action.FEED) {
            walking = elapsed < 720;
            eating = !walking;
            catX = move(startX, 58, elapsed / 720f);
            PixelHomeView.drawBowl(canvas, paint, 30, GROUND - 1, .70f);
        } else if (action == MochiCare.Action.PLAY) {
            walking = true;
            float ball = 91;
            if (elapsed < 600) {
                catX = move(startX, 70, elapsed / 600f);
            } else {
                double phase = (elapsed - 600) / 390.0;
                catX = 70 + 35 * (float) Math.sin(phase);
                hop = 7 * (float) Math.abs(Math.sin(phase * 2.1));
                ball = 70 + 48 * (float) Math.sin(phase + .45);
            }
            PixelHomeView.drawYarn(canvas, paint, ball, GROUND - 3 - hop * .45f, .62f);
        } else if (action == null) {
            long phase = elapsed % IDLE_LOOP_MS;
            if (phase < 2900) {
                catX = elapsed < IDLE_LOOP_MS ? startX : LEFT;
            } else if (phase < 5850) {
                float from = elapsed < IDLE_LOOP_MS ? startX : LEFT;
                catX = move(from, RIGHT, (phase - 2900) / 2950f);
                walking = true;
            } else if (phase < 8300) {
                catX = RIGHT;
            } else if (phase < 11200) {
                catX = move(RIGHT, LEFT, (phase - 8300) / 2900f);
                walking = true;
            } else {
                catX = LEFT;
            }
        }

        if (eating) faceRight = false;
        else if (Math.abs(catX - previousX) > .01f) faceRight = catX > previousX;
        boolean blink = now % 3700 < 170;
        int step = (int) ((now / 145) % 4);
        boolean dip = eating && (now / 220) % 2 == 0;

        paint.setColor(0x56354236);
        canvas.drawOval(catX - 19, GROUND - 3, catX + 20, GROUND + 4, paint);
        drawCat(canvas, catX, GROUND - hop, faceRight, walking, step, eating, dip, asleep, blink);
        if (action == MochiCare.Action.PET) {
            float y = 23 - elapsed / 105f;
            paint.setColor(0xffe27b9f);
            canvas.drawRect(catX - 6, y - 3, catX + 6, y + 1, paint);
            canvas.drawRect(catX - 4, y - 6, catX - 1, y - 3, paint);
            canvas.drawRect(catX + 1, y - 6, catX + 4, y - 3, paint);
            canvas.drawRect(catX - 3, y + 1, catX + 3, y + 4, paint);
            canvas.drawRect(catX - 1, y + 4, catX + 1, y + 6, paint);
        } else if (asleep) {
            text(canvas, "z", catX + 23, 38 - (elapsed % 1500) / 125f,
                12, 0xff58407b, android.graphics.Paint.Align.CENTER);
            text(canvas, "z", catX + 34, 25 - (elapsed % 1500) / 125f,
                9, 0xff58407b, android.graphics.Paint.Align.CENTER);
        }

        if (running) {
            removeCallbacks(frame);
            postDelayed(frame, 80);
        }
    }

    private void drawCat(Canvas canvas, float x, float y, boolean right, boolean walking,
            int step, boolean eating, boolean dipping, boolean asleep, boolean blink) {
        canvas.save();
        canvas.translate(Math.round(x), Math.round(y));
        canvas.scale(right ? 2.16f : -2.16f, 2.16f);
        paint.setAntiAlias(false);

        int tail = step < 2 ? 1 : 0;
        pixels(canvas, -11, -10 - tail, -8, -4, INK);
        pixels(canvas, -13, -11 - tail, -9, -8 - tail, INK);
        pixels(canvas, -12, -10 - tail, -10, -9 - tail, GOLD);
        pixels(canvas, -10, -9 - tail, -9, -4, GOLD);
        pixels(canvas, -10, -5, -6, -3, INK);
        pixels(canvas, -9, -5, -6, -4, GOLD);

        if (walking || asleep) {
            sprite(canvas, WALKING_BODY, -10, asleep ? -6 : -8);
            if (walking) {
                int swing = step < 2 ? step : 2 - step;
                paw(canvas, -8 + swing, -3);
                paw(canvas, -4 - swing, -4);
                paw(canvas, 1 - swing, -3);
                paw(canvas, 5 + swing, -4);
            }
        } else {
            sprite(canvas, SITTING_BODY, -7, -8);
            paw(canvas, 0, -3);
            paw(canvas, 4, -3);
        }

        int headX = walking || asleep || eating ? 0 : -6;
        int headY = -19;
        if (asleep) headY = -12;
        else if (eating) headY = dipping ? -13 : -15;
        else if (walking) headY = -18 + step % 2;
        sprite(canvas, HEAD, headX, headY);
        if (blink || asleep || dipping) {
            pixels(canvas, headX + 4, headY + 8, headX + 7, headY + 9, INK);
            pixels(canvas, headX + 10, headY + 8, headX + 13, headY + 9, INK);
        } else {
            pixels(canvas, headX + 5, headY + 7, headX + 7, headY + 9, INK);
            pixels(canvas, headX + 10, headY + 7, headX + 12, headY + 9, INK);
        }
        pixels(canvas, headX + 8, headY + 9, headX + 10, headY + 10, PINK);
        pixels(canvas, headX + 8, headY + 10, headX + 9, headY + 11, INK);
        if (!asleep) {
            pixels(canvas, headX + 3, headY + 11, headX + 12, headY + 12, INK);
            pixels(canvas, headX + 4, headY + 11, headX + 11, headY + 12, LILAC);
            pixels(canvas, headX + 6, headY + 12, headX + 8, headY + 13, LILAC);
        }

        paint.setAntiAlias(true);
        canvas.restore();
    }

    private void paw(Canvas canvas, int x, int y) {
        pixels(canvas, x, y, x + 4, y + 3, INK);
        pixels(canvas, x + 1, y, x + 3, y + 2, CREAM);
    }

    private void sprite(Canvas canvas, String[] rows, int x, int y) {
        for (int row = 0; row < rows.length; row++) {
            String line = rows[row];
            for (int column = 0; column < line.length(); column++) {
                int color;
                switch (line.charAt(column)) {
                    case '#': color = INK; break;
                    case 'c': color = CREAM; break;
                    case 'a': color = GOLD; break;
                    case 'p': color = PINK; break;
                    default: continue;
                }
                pixels(canvas, x + column, y + row, x + column + 1, y + row + 1, color);
            }
        }
    }

    private void pixels(Canvas canvas, int left, int top, int right, int bottom, int color) {
        paint.setColor(color);
        canvas.drawRect(left, top, right, bottom, paint);
    }

    private static float move(float from, float to, float fraction) {
        float t = Math.max(0, Math.min(1, fraction));
        return from + (to - from) * t * t * (3 - 2 * t);
    }

    private static long actionDuration(MochiCare.Action action) {
        switch (action) {
            case FEED: return 3900;
            case PLAY: return 5600;
            case PET: return 2200;
            case REST: return 8000;
            default: throw new AssertionError(action);
        }
    }
}
