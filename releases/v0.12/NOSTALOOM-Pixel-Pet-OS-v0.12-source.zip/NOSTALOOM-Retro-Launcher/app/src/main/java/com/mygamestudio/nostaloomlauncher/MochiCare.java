package com.mygamestudio.nostaloomlauncher;

final class MochiCare {
    enum Action { FEED, PLAY, PET, REST }

    private static final long INTERVAL_MS = 15 * 60 * 1000L;
    int happiness;
    int fullness;
    int energy;
    long updatedAt;

    MochiCare(int happiness, int fullness, int energy, long updatedAt) {
        this.happiness = limit(happiness);
        this.fullness = limit(fullness);
        this.energy = limit(energy);
        this.updatedAt = updatedAt;
    }

    void update(long now) {
        if (updatedAt <= 0 || updatedAt > now) updatedAt = now;
        long steps = (now - updatedAt) / INTERVAL_MS;
        if (steps == 0) return;
        int elapsed = (int) Math.min(100, steps);
        fullness = limit(fullness - elapsed * 3);
        happiness = limit(happiness - elapsed);
        energy = limit(energy + elapsed * 3);
        updatedAt += steps * INTERVAL_MS;
    }

    boolean act(Action action) {
        switch (action) {
            case FEED:
                fullness = limit(fullness + 25);
                happiness = limit(happiness + 4);
                return true;
            case PLAY:
                if (energy < 12) return false;
                happiness = limit(happiness + 16);
                energy -= 12;
                fullness = limit(fullness - 5);
                return true;
            case PET:
                happiness = limit(happiness + 5);
                return true;
            case REST:
                energy = limit(energy + 24);
                return true;
            default:
                throw new AssertionError(action);
        }
    }

    private static int limit(int value) {
        return Math.max(0, Math.min(100, value));
    }
}
