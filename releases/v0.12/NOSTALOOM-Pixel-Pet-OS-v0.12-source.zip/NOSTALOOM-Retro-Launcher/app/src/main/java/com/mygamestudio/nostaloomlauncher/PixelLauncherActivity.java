package com.mygamestudio.nostaloomlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ComponentName;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ResolveInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.DragEvent;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.EnumMap;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;

public class PixelLauncherActivity extends Activity {
    private static final Locale MALAY = new Locale("ms", "MY");
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final String[] defaultTabs = {
        "facebook", "youtube", "tiktok", "chrome", "explorer", "whatsapp", "gallery", "camera", "lock"
    };
    private final List<ResolveInfo> apps = new ArrayList<>();
    private final EnumMap<SocialApp, PixelHomeView.Fruit> fruits = new EnumMap<>(SocialApp.class);
    private final SimpleDateFormat timeFormat = new SimpleDateFormat("HH:mm", Locale.US);
    private final SimpleDateFormat dateFormat = new SimpleDateFormat("EEE dd MMM", MALAY);
    private final Runnable onNotificationChange = this::refreshFruits;
    private final Runnable resetPetLabel = () -> setPetLabel("Mochi");
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            long now = System.currentTimeMillis();
            refreshDeviceTime(now);
            long updatedAt = pet.updatedAt;
            pet.update(now);
            if (pet.updatedAt != updatedAt) {
                savePet();
                petPanel.refresh(petLabel);
            }
            handler.postDelayed(this, Math.min(15000, 60000 - now % 60000 + 35));
        }
    };

    private PixelHomeView screen;
    private PixelHomeView.DotClock clock;
    private PixelHomeView.DeviceLine deviceLine;
    private PixelHomeView.DatePlate datePlate;
    private PixelHomeView.PetPanel petPanel;
    private MochiSpriteView petSprite;
    private LinearLayout tabRail;
    private SharedPreferences preferences;
    private MochiCare pet;
    private String petLabel = "Mochi";

    @Override public void onCreate(Bundle saved) {
        super.onCreate(saved);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN);
        preferences = getPreferences(MODE_PRIVATE);
        pet = new MochiCare(preferences.getInt("pet_happiness", 76),
            preferences.getInt("pet_fullness", 62), preferences.getInt("pet_energy", 80),
            preferences.getLong("pet_updated", System.currentTimeMillis()));
        pet.update(System.currentTimeMillis());
        screen = new PixelHomeView(this);
        buildHome();
        setContentView(screen);
    }

    @Override protected void onStart() {
        super.onStart();
        NotificationFruitService.observe(onNotificationChange);
        petSprite.setRunning(true);
        handler.post(tick);
    }

    @Override protected void onResume() {
        super.onResume();
        refreshFruits();
    }

    @Override protected void onStop() {
        handler.removeCallbacks(tick);
        handler.removeCallbacks(resetPetLabel);
        NotificationFruitService.removeObserver(onNotificationChange);
        petSprite.setRunning(false);
        setPetLabel("Mochi");
        savePet();
        super.onStop();
    }

    private void buildHome() {
        deviceLine = new PixelHomeView.DeviceLine(this);
        screen.place(deviceLine, 0, 0, 540, 34);
        clock = new PixelHomeView.DotClock(this);
        screen.place(clock, 67, 132, 198, 77);
        datePlate = new PixelHomeView.DatePlate(this);
        screen.place(datePlate, 128, 212, 124, 29);

        fruit(SocialApp.TIKTOK, 35, 274);
        fruit(SocialApp.YOUTUBE, 82, 260);
        fruit(SocialApp.WHATSAPP, 129, 264);
        fruit(SocialApp.FACEBOOK, 176, 269);

        petSprite = new MochiSpriteView(this);
        screen.place(petSprite, 194, 323, MochiSpriteView.WIDTH, MochiSpriteView.HEIGHT);
        petSprite.setOnClickListener(view -> petAction(MochiCare.Action.PET));
        petSprite.setOnLongClickListener(view -> {
            petMenu();
            return true;
        });

        petPanel = new PixelHomeView.PetPanel(this, pet);
        screen.place(petPanel, 196, 590, 230, 131);
        tapZone("Menu Mochi", 32, 552, 157, 155, this::petMenu);
        addPetButton(true, 205, 121, MochiCare.Action.FEED);
        addPetButton(false, 331, 93, MochiCare.Action.PLAY);

        tapZone("Camera", 26, 749, 92, 112, this::camera);
        tapZone("Gallery", 131, 749, 93, 112, this::gallery);
        tapZone("Music", 239, 749, 94, 112, this::music);
        tapZone("Files", 349, 749, 92, 112, this::files);
        View settings = tapZone("Settings", 30, 874, 100, 115, this::systemSettings);
        settings.setOnLongClickListener(view -> {
            startMenu();
            return true;
        });
        tapZone("Browser", 152, 874, 104, 115, this::browser);

        socialShortcut(SocialApp.WHATSAPP, 531);
        socialShortcut(SocialApp.FACEBOOK, 623);
        socialShortcut(SocialApp.YOUTUBE, 721);
        socialShortcut(SocialApp.TIKTOK, 815);

        tapZone("Phone", 55, 1060, 153, 88,
            () -> openIntent(new Intent(Intent.ACTION_DIAL)));
        tapZone("Messages", 212, 1060, 192, 88, this::messages);
        View drawer = tapZone("Semua aplikasi", 410, 1060, 98, 88, this::appDrawer);
        drawer.setOnLongClickListener(view -> {
            startMenu();
            return true;
        });
    }

    private View tapZone(String label, int x, int y, int width, int height, Runnable action) {
        View zone = new View(this);
        zone.setContentDescription(label);
        zone.setFocusable(true);
        zone.setOnClickListener(view -> action.run());
        screen.place(zone, x, y, width, height);
        return zone;
    }

    private void fruit(SocialApp app, int x, int y) {
        PixelHomeView.Fruit fruit = new PixelHomeView.Fruit(this, app);
        fruits.put(app, fruit);
        screen.place(fruit, x, y, 46, 54);
        fruit.setFocusable(true);
        fruit.setOnClickListener(view -> {
            if (NotificationFruitService.hasAccess(this)) openSocial(app);
            else showNotificationAccess(app);
        });
    }

    private void socialShortcut(SocialApp app, int y) {
        View shortcut = tapZone(app.label, 452, y, 78, 70, () -> openSocial(app));
        shortcut.setOnLongClickListener(view -> {
            showTabs();
            return true;
        });
    }

    private void addPetButton(boolean food, int x, int width, MochiCare.Action action) {
        PixelHomeView.PetButton button = new PixelHomeView.PetButton(this, width, food);
        screen.place(button, x, 683, width, 38);
        button.setFocusable(true);
        button.setOnClickListener(view -> petAction(action));
    }

    private void refreshDeviceTime(long now) {
        TimeZone timeZone = TimeZone.getDefault();
        timeFormat.setTimeZone(timeZone);
        dateFormat.setTimeZone(timeZone);
        Date date = new Date(now);
        String time = timeFormat.format(date);
        clock.setTime(time);
        datePlate.setDate(dateFormat.format(date).toUpperCase(MALAY));
        Intent battery = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        int level = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = battery == null ? -1 : battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        deviceLine.setValues(time, level < 0 || scale <= 0 ? -1 : level * 100 / scale);
    }

    private void refreshFruits() {
        NotificationFruitService.Snapshot snapshot = NotificationFruitService.current();
        boolean ready = snapshot.ready && NotificationFruitService.hasAccess(this);
        for (SocialApp app : SocialApp.values()) {
            fruits.get(app).setCount(ready ? snapshot.count(app) : -1);
        }
    }

    private void showNotificationAccess(SocialApp shortcut) {
        AlertDialog.Builder dialog = new AlertDialog.Builder(this)
            .setTitle("Akses Notifikasi")
            .setMessage("Benarkan NOSTALOOM mengira notifikasi aktif untuk TikTok, YouTube, "
                + "WhatsApp dan Facebook. Nombor berubah apabila notifikasi tiba atau dibuang.")
            .setPositiveButton("Buka Tetapan", (d, which) -> {
                try {
                    startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                } catch (ActivityNotFoundException exception) {
                    Toast.makeText(this, "Cari Akses Notifikasi dalam Tetapan Android.",
                        Toast.LENGTH_LONG).show();
                }
            })
            .setNegativeButton("Tutup", null);
        if (shortcut != null) {
            dialog.setNeutralButton("Buka " + shortcut.label, (d, which) -> openSocial(shortcut));
        }
        dialog.show();
    }

    private void openSocial(SocialApp app) {
        String latest = NotificationFruitService.current().latestPackage(app);
        if (latest != null && launchInstalled(latest)) return;
        for (String packageName : app.packages) {
            if (!packageName.equals(latest) && launchInstalled(packageName)) return;
        }
        openWebsite(app.website);
    }

    private void petMenu() {
        new AlertDialog.Builder(this).setTitle("Mochi")
            .setItems(new String[]{"Beri Makan", "Main", "Belai", "Rehat"},
                (dialog, which) -> petAction(MochiCare.Action.values()[which]))
            .setNegativeButton("Tutup", null).show();
    }

    private void petAction(MochiCare.Action action) {
        pet.update(System.currentTimeMillis());
        if (pet.act(action)) {
            petSprite.begin(action);
            switch (action) {
                case FEED: setPetLabel("Mochi sedang makan"); break;
                case PLAY: setPetLabel("Mochi mengejar benang"); break;
                case PET: setPetLabel("Mochi suka dibelai"); break;
                case REST: setPetLabel("Mochi sedang tidur"); break;
            }
        } else {
            setPetLabel("Mochi perlu rehat");
        }
        savePet();
        handler.removeCallbacks(resetPetLabel);
        handler.postDelayed(resetPetLabel, action == MochiCare.Action.REST ? 8000 : 4500);
    }

    private void setPetLabel(String label) {
        petLabel = label;
        petPanel.refresh(label);
    }

    private void savePet() {
        preferences.edit().putInt("pet_happiness", pet.happiness)
            .putInt("pet_fullness", pet.fullness).putInt("pet_energy", pet.energy)
            .putLong("pet_updated", pet.updatedAt).apply();
    }

    private void showTabs() {
        LinearLayout rail = new LinearLayout(this);
        rail.setOrientation(LinearLayout.VERTICAL);
        rail.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout panel = new LinearLayout(this);
        panel.addView(rail, new LinearLayout.LayoutParams(-1, dp(446)));
        tabRail = rail;
        refreshTabs();
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle("Tab Sisi")
            .setView(panel).setNegativeButton("Tutup", null).create();
        dialog.setOnDismissListener(ignored -> {
            if (tabRail == rail) tabRail = null;
        });
        dialog.show();
    }

    private int dp(int value) {
        return Math.round(getResources().getDisplayMetrics().density * value);
    }

    private String[] readTabs() {
        String serialized=getPreferences(MODE_PRIVATE).getString("tab_order","");
        String[] order=serialized.split(",");
        if(order.length!=defaultTabs.length) return defaultTabs.clone();
        java.util.HashSet<String> seen=new java.util.HashSet<>();
        for(String tab:order) seen.add(tab);
        for(String tab:defaultTabs) if(!seen.contains(tab)) return defaultTabs.clone();
        return order;
    }
    private void refreshTabs() {
        if(tabRail==null)return;
        tabRail.removeAllViews();
        String[] tabs=readTabs();
        for(int i=0;i<tabs.length;i++) {
            final String id=tabs[i];
            TapeTabView tab=new TapeTabView(id);
            LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,0,1);
            p.setMargins(0,dp(2),0,dp(2));tabRail.addView(tab,p);
            tab.setContentDescription("Open " + tab + ". Long press to reorder.");
            tab.setOnClickListener(v->launchTab(id));
            tab.setOnLongClickListener(v->{
                ClipData clip=ClipData.newPlainText("nostaloom-tab",id);
                View.DragShadowBuilder shadow = new View.DragShadowBuilder(v);
                if (Build.VERSION.SDK_INT >= 24) return v.startDragAndDrop(clip, shadow, null, 0);
                return v.startDrag(clip, shadow, null, 0);
            });
            tab.setOnDragListener((view,event)->{
                if(event.getAction()==DragEvent.ACTION_DRAG_STARTED) return true;
                if(event.getAction()==DragEvent.ACTION_DRAG_ENTERED){view.setAlpha(.65f);return true;}
                if(event.getAction()==DragEvent.ACTION_DRAG_EXITED || event.getAction()==DragEvent.ACTION_DRAG_ENDED){view.setAlpha(1f);return true;}
                if(event.getAction()==DragEvent.ACTION_DROP){
                    try {
                        String moving=event.getClipData().getItemAt(0).getText().toString();
                        String[] order=readTabs();int from=-1,to=-1;
                        for(int j=0;j<order.length;j++) {if(order[j].equals(moving))from=j;if(order[j].equals(id))to=j;}
                        if(from>=0 && to>=0 && from!=to) {
                            String temp=order[to];order[to]=order[from];order[from]=temp;
                            getPreferences(MODE_PRIVATE).edit().putString("tab_order",android.text.TextUtils.join(",",order)).apply();
                            refreshTabs();
                        }
                    } catch(Exception ignored) {}
                    return true;
                }
                return true;
            });
        }
    }
    private void launchTab(String id) {
        SocialApp social = SocialApp.fromTab(id);
        if (social != null) {
            openSocial(social);
            return;
        }
        switch (id) {
            case "chrome": if (!launchInstalled("com.android.chrome")) browser(); break;
            case "explorer": files(); break;
            case "gallery": gallery(); break;
            case "camera": camera(); break;
            case "lock": openIntent(new Intent(Settings.ACTION_SECURITY_SETTINGS)); break;
        }
    }

    private class TapeTabView extends View {
        private final String name;
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        private final int shade;
        TapeTabView(String id) {
            super(PixelLauncherActivity.this);name=id;
            switch(id) {
                case "facebook":shade=0xff3365aa;break;
                case "youtube":shade=0xffd64242;break;
                case "tiktok":shade=0xff8051b0;break;
                case "chrome":shade=0xffd79032;break;
                case "explorer":shade=0xffb5b94b;break;
                case "whatsapp":shade=0xff36b257;break;
                case "gallery":shade=0xff328e95;break;
                case "camera":shade=0xff5c5869;break;
                default:shade=0xff303f64;
            }
            setLayerType(View.LAYER_TYPE_SOFTWARE,null);
        }
        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);float w=getWidth(),h=getHeight();
            Path paper=new Path();paper.moveTo(w*.14f,h*.04f);paper.lineTo(w*.96f,0);
            paper.lineTo(w,h*.15f);paper.lineTo(w*.98f,h*.43f);
            paper.lineTo(w,h*.66f);paper.lineTo(w*.97f,h*.97f);
            paper.lineTo(w*.16f,h);paper.lineTo(w*.12f,h*.88f);
            paper.lineTo(w*.07f,h*.78f);paper.lineTo(w*.14f,h*.67f);
            paper.lineTo(w*.075f,h*.54f);paper.lineTo(w*.14f,h*.42f);
            paper.lineTo(w*.08f,h*.28f);paper.lineTo(w*.15f,h*.16f);paper.close();
            paint.setStyle(Paint.Style.FILL);paint.setColor(shade);
            paint.setShadowLayer(dp(3),-dp(2),dp(2),0x990d1322);c.drawPath(paper,paint);paint.clearShadowLayer();
            paint.setColor(0x55ffffff);paint.setStrokeWidth(dp(1));
            c.drawLine(w*.2f,h*.12f,w*.86f,h*.08f,paint);
            paint.setColor(Color.WHITE);paint.setTypeface(Typeface.create("sans-serif-condensed",Typeface.BOLD));
            paint.setTextSize(Math.max(dp(10),Math.min(dp(14),h*.24f)));
            String title=name.equals("explorer")?"Explorer":name.equals("gallery")?"Galeri":
                name.equals("lock")?"Lockscreen":Character.toUpperCase(name.charAt(0))+name.substring(1);
            float size=paint.getTextSize();
            while(paint.measureText(title)>w*.77f && size>dp(8)) {size-=1f;paint.setTextSize(size);}
            paint.setTextAlign(Paint.Align.CENTER);c.drawText(title,w*.57f,h*.59f,paint);
        }
    }
    private boolean launchInstalled(String packageName) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(packageName);
        if (launch == null) return false;
        try {
            startActivity(launch);
            return true;
        } catch (ActivityNotFoundException | SecurityException exception) {
            return false;
        }
    }

    private void openWebsite(String website) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(website)));
        } catch (ActivityNotFoundException exception) {
            Toast.makeText(this, "Aplikasi tidak tersedia.", Toast.LENGTH_SHORT).show();
        }
    }

    private void openIntent(Intent intent) {
        try {startActivity(intent);} catch(Exception e){appDrawer();}
    }
    private void camera() {openIntent(new Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA));}
    private void music() {
        Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_APP_MUSIC);openIntent(i);
    }
    private void gallery() {Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");openIntent(i);}
    private void messages() {Intent i=new Intent(Intent.ACTION_MAIN);i.addCategory(Intent.CATEGORY_APP_MESSAGING);openIntent(i);}
    private void browser() {openIntent(new Intent(Intent.ACTION_VIEW,Uri.parse("https://www.google.com")));}
    private void systemSettings() {openIntent(new Intent(Settings.ACTION_SETTINGS));}
    private void files() {Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("*/*");i.addCategory(Intent.CATEGORY_OPENABLE);openIntent(i);}
    private void startMenu() {
        new AlertDialog.Builder(this).setTitle("Menu NOSTALOOM")
            .setItems(new String[]{"Semua aplikasi", "Folder", "Classic Cute Desktop",
                "Tab Sisi", "Akses Notifikasi", "Tetapan Android", "Pilih Launcher Utama"},
                (dialog, which) -> {
                    switch (which) {
                        case 0: appDrawer(); break;
                        case 1: folders(); break;
                        case 2: startActivity(new Intent(this, LauncherActivity.class)); break;
                        case 3: showTabs(); break;
                        case 4: showNotificationAccess(null); break;
                        case 5: systemSettings(); break;
                        case 6: openIntent(new Intent(Settings.ACTION_HOME_SETTINGS)); break;
                    }
                }).show();
    }

    private void loadApps() {
        Intent main=new Intent(Intent.ACTION_MAIN);main.addCategory(Intent.CATEGORY_LAUNCHER);
        apps.clear(); apps.addAll(getPackageManager().queryIntentActivities(main,0));
        Collections.sort(apps,Comparator.comparing(a->a.loadLabel(getPackageManager()).toString().toLowerCase(Locale.getDefault())));
    }
    private void appDrawer() {
        loadApps();
        LinearLayout content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);
        EditText query=new EditText(this);query.setSingleLine(true);query.setHint("Search installed apps...");content.addView(query);
        ListView list=new ListView(this);content.addView(list,new LinearLayout.LayoutParams(-1,dp(380)));
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("▣ PIXEL APP DRAWER")
            .setView(content).setNeutralButton("Menu Launcher", (d, which) -> startMenu())
            .setNegativeButton("Tutup", null).create();
        final List<ResolveInfo> visible=new ArrayList<>();
        Runnable refresh=()->{
            visible.clear();String needle=query.getText().toString().trim().toLowerCase(Locale.getDefault());
            List<String> names=new ArrayList<>();
            for(ResolveInfo info:apps) {
                String name=info.loadLabel(getPackageManager()).toString();
                if(name.toLowerCase(Locale.getDefault()).contains(needle)){visible.add(info);names.add(name);}
            }
            list.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_list_item_1,names));
        };
        query.addTextChangedListener(new android.text.TextWatcher(){
            public void beforeTextChanged(CharSequence s,int st,int count,int after){}
            public void onTextChanged(CharSequence s,int st,int before,int count){refresh.run();}
            public void afterTextChanged(android.text.Editable e){}
        });
        list.setOnItemClickListener((parent,view,index,id)->{
            ResolveInfo info=visible.get(index);Intent launch=new Intent(Intent.ACTION_MAIN);
            launch.addCategory(Intent.CATEGORY_LAUNCHER);launch.setComponent(new ComponentName(info.activityInfo.packageName,info.activityInfo.name));
            launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);openIntent(launch);dialog.dismiss();
        });
        list.setOnItemLongClickListener((parent,view,index,id)->{
            ResolveInfo info=visible.get(index);String component=info.activityInfo.packageName+"/"+info.activityInfo.name;
            new AlertDialog.Builder(this).setTitle(info.loadLabel(getPackageManager()))
                .setItems(new String[]{"Add to Classic Desktop", "Add to Folder"},(d,which)->{
                    if(which==0) addToClassicDesktop(component);else addToFolder(component);
                }).show();return true;
        });
        refresh.run();dialog.show();
    }
    private void addToClassicDesktop(String component) {
        android.content.SharedPreferences prefs=getSharedPreferences("launcher_layout",MODE_PRIVATE);
        try {
            JSONArray slots=new JSONArray(prefs.getString("slots","[]"));
            String value="app:"+component;
            for(int i=0;i<slots.length();i++) if(value.equals(slots.optString(i))) return;
            for(int i=0;i<80;i++) if(slots.optString(i,"").isEmpty()) {
                slots.put(i,value);prefs.edit().putString("slots",slots.toString()).apply();
                Toast.makeText(this,"Added to Classic Desktop",Toast.LENGTH_SHORT).show();return;
            }
        } catch(Exception ignored) {}
        Toast.makeText(this,"Open Classic Desktop to arrange apps",Toast.LENGTH_LONG).show();
    }
    private void folders() {
        JSONObject saved;
        try {saved=new JSONObject(getSharedPreferences("desktop_folders",MODE_PRIVATE).getString("folders","{}"));}
        catch(Exception e){saved=new JSONObject();}
        JSONArray names=saved.names();
        if(names==null || names.length()==0){Toast.makeText(this,"Create folders in Classic Desktop",Toast.LENGTH_LONG).show();return;}
        String[] labels=new String[names.length()];for(int i=0;i<labels.length;i++)labels[i]=names.optString(i);
        JSONObject folders=saved;
        new AlertDialog.Builder(this).setTitle("📁 PIXEL TREASURE CHESTS")
            .setItems(labels,(d,which)->openFolder(labels[which],folders.optJSONArray(labels[which]))).show();
    }
    private void openFolder(String name,JSONArray list) {
        if(list==null)return;
        List<String> labels=new ArrayList<>(),components=new ArrayList<>();
        for(int i=0;i<list.length();i++) {
            String value=list.optString(i);String[] p=value.split("/",2);if(p.length!=2)continue;
            try {String label=getPackageManager().getActivityInfo(new ComponentName(p[0],p[1]),0).loadLabel(getPackageManager()).toString();
                labels.add(label);components.add(value);}catch(Exception ignored){}
        }
        if(labels.isEmpty()){Toast.makeText(this,"This folder is empty",Toast.LENGTH_SHORT).show();return;}
        new AlertDialog.Builder(this).setTitle("📁 "+name)
            .setItems(labels.toArray(new String[0]),(d,which)->{
                String[] p=components.get(which).split("/",2);Intent intent=new Intent(Intent.ACTION_MAIN);
                intent.addCategory(Intent.CATEGORY_LAUNCHER);intent.setComponent(new ComponentName(p[0],p[1]));openIntent(intent);
            }).show();
    }
    private void addToFolder(String component) {
        try {
            android.content.SharedPreferences prefs=getSharedPreferences("desktop_folders",MODE_PRIVATE);
            JSONObject folders=new JSONObject(prefs.getString("folders","{}"));JSONArray names=folders.names();
            if(names==null){Toast.makeText(this,"Create a folder in Classic Desktop first",Toast.LENGTH_LONG).show();return;}
            String[] labels=new String[names.length()];for(int i=0;i<labels.length;i++)labels[i]=names.optString(i);
            new AlertDialog.Builder(this).setTitle("ADD TO FOLDER")
                .setItems(labels,(d,index)->{
                    JSONArray arr=folders.optJSONArray(labels[index]);if(arr==null)return;
                    for(int j=0;j<arr.length();j++)if(component.equals(arr.optString(j)))return;
                    arr.put(component);prefs.edit().putString("folders",folders.toString()).apply();
                    Toast.makeText(this,"Added to "+labels[index],Toast.LENGTH_SHORT).show();
                }).show();
        }catch(Exception ignored){}
    }
    @Override protected void onDestroy(){handler.removeCallbacksAndMessages(null);super.onDestroy();}
}
