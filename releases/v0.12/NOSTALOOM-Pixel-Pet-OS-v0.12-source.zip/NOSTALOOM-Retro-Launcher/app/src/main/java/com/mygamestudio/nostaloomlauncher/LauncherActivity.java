package com.mygamestudio.nostaloomlauncher;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.WallpaperManager;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ClipData;
import android.content.SharedPreferences;
import android.os.BatteryManager;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.DragEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.*;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.Iterator;

public class LauncherActivity extends Activity {
    private final int navy = Color.rgb(116, 160, 180), grey = Color.rgb(246, 222, 235);
    private final Handler handler = new Handler();
    private LinearLayout desktop, taskbar, drawer, appList;
    private GridLayout desktopGrid;
    private TextView pageLabel;
    private int page = 0;
    private int columns = 4;
    private int totalPages = 3;
    private TextView clock;
    private TextView battery;
    private TextView petMessage;
    private PetView petView;
    private int petType = 0;
    private int petMood = 0;
    private EditText search;
    private final List<ResolveInfo> apps = new ArrayList<>();
    private PackageManager pm;
    private boolean drawerVisible;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        pm = getPackageManager();
        SharedPreferences ui = getSharedPreferences("launcher_options", MODE_PRIVATE);
        columns = ui.getInt("columns",4);
        totalPages = ui.getInt("pages",3);
        petType = ui.getInt("pet",0);
        createUi();
        handler.post(new Runnable() {
            @Override public void run() {
                if (clock != null) clock.setText(new SimpleDateFormat("HH:mm  •  dd/MM", Locale.getDefault()).format(new Date()));
                if (battery != null) {
                    Intent b = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
                    int level = b == null ? -1 : b.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
                    int scale = b == null ? -1 : b.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
                    battery.setText(level >= 0 && scale > 0 ? "▣ " + (level * 100 / scale) + "%" : "▣ --%");
                }
                handler.postDelayed(this, 15000);
            }
        });
    }

    private GradientDrawable panel(int color, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color); g.setStroke(dp(2), stroke); g.setCornerRadius(dp(2)); return g;
    }
    private int dp(int v) { return (int)(getResources().getDisplayMetrics().density * v + .5f); }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        t.setGravity(Gravity.CENTER_VERTICAL); t.setPadding(dp(9), dp(6), dp(9), dp(6));
        if (bold) t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        return t;
    }
    private void createUi() {
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
            new int[]{0xff9fcde1,0xffb7a7d7,0xfff2c9da})); setContentView(root);
        FrameLayout area = new FrameLayout(this);
        root.addView(area, new LinearLayout.LayoutParams(-1, 0, 1));
        ScrollView desktopScroller = new ScrollView(this); desktopScroller.setFillViewport(true);
        area.addView(desktopScroller, new FrameLayout.LayoutParams(-1, -1));
        desktop = new LinearLayout(this); desktop.setOrientation(LinearLayout.VERTICAL); desktop.setPadding(dp(14), dp(20), dp(14), dp(8));
        desktopScroller.addView(desktop);
        TextView title = text("♡ NOSTALOOM PET HOME", 20, Color.WHITE, true); desktop.addView(title);
        TextView subtitle = text("MY CUTE LITTLE DESKTOP FRIEND", 11, Color.WHITE, false); desktop.addView(subtitle);
        LinearLayout pager = new LinearLayout(this); pager.setGravity(Gravity.CENTER_VERTICAL);
        desktop.addView(pager);
        TextView previous = text("◀", 20, Color.WHITE, true); pager.addView(previous);
        previous.setOnClickListener(v -> { page = (page + totalPages - 1) % totalPages; renderDesktop(); });
        enablePageDrop(previous,-1);
        pageLabel = text("DESKTOP 1/3", 13, Color.WHITE, true); pageLabel.setGravity(Gravity.CENTER);
        pager.addView(pageLabel, new LinearLayout.LayoutParams(0,dp(42),1));
        TextView next = text("▶",20,Color.WHITE,true); pager.addView(next);
        next.setOnClickListener(v -> { page = (page + 1) % totalPages; renderDesktop(); });
        enablePageDrop(next,1);
        desktopGrid = new GridLayout(this); desktopGrid.setColumnCount(columns);
        desktop.addView(desktopGrid); renderDesktop();
        TextView help = text("Hold an icon to move • Hold an app to add", 11, 0xffb8d6d7, false); desktop.addView(help);
        LinearLayout petZone = new LinearLayout(this); petZone.setOrientation(LinearLayout.VERTICAL);
        petZone.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams petParams=new FrameLayout.LayoutParams(dp(146),dp(184),Gravity.BOTTOM|Gravity.RIGHT);
        petParams.setMargins(0,0,dp(10),dp(12)); area.addView(petZone,petParams);
        petMessage=text("♡ TAP ME!",12,0xff704568,true); petMessage.setGravity(Gravity.CENTER);
        petMessage.setBackground(panel(0xfffff3f8,0xffedb4d4)); petZone.addView(petMessage);
        petView = new PetView(); petZone.addView(petView,new LinearLayout.LayoutParams(dp(135),dp(145)));
        petView.setOnClickListener(v -> interactPet());
        petView.setOnLongClickListener(v -> { choosePet(); return true; });
        TextView foot = text("myGAMEstudio • v0.04", 10, 0xfff9f5ff, false);
        FrameLayout.LayoutParams footParams = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.RIGHT);
        footParams.setMargins(0,0,dp(150),dp(10)); area.addView(foot, footParams);

        drawer = new LinearLayout(this); drawer.setOrientation(LinearLayout.VERTICAL); drawer.setBackground(panel(grey, Color.WHITE));
        FrameLayout.LayoutParams drawerParams = new FrameLayout.LayoutParams(-1, -1);
        drawerParams.setMargins(dp(8), dp(64), dp(8), dp(8)); area.addView(drawer, drawerParams);
        TextView header = text("▣  START MENU  •  ALL PROGRAMS", 16, Color.WHITE, true); header.setBackgroundColor(0xff101e77); drawer.addView(header);
        TextView newFolder = text("📁  CREATE NEW FOLDER", 14, Color.BLACK, true); drawer.addView(newFolder);
        newFolder.setOnClickListener(v -> createFolder());
        TextView options = text("⚙  LAUNCHER SETTINGS", 14, Color.BLACK, true); drawer.addView(options);
        options.setOnClickListener(v -> launcherSettings());
        search = new EditText(this); search.setSingleLine(true); search.setTextSize(15); search.setHint("Search apps...");
        drawer.addView(search, new LinearLayout.LayoutParams(-1, dp(48)));
        ScrollView scroller = new ScrollView(this); drawer.addView(scroller, new LinearLayout.LayoutParams(-1, 0, 1));
        appList = new LinearLayout(this); appList.setOrientation(LinearLayout.VERTICAL); scroller.addView(appList);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s,int st,int c,int a) {}
            @Override public void onTextChanged(CharSequence s,int st,int before,int count) { populate(s.toString()); }
            @Override public void afterTextChanged(Editable e) {}
        });
        drawer.setVisibility(View.GONE);

        taskbar = new LinearLayout(this); taskbar.setGravity(Gravity.CENTER_VERTICAL);
        taskbar.setPadding(dp(4),dp(4),dp(4),dp(4)); taskbar.setBackgroundColor(grey);
        root.addView(taskbar, new LinearLayout.LayoutParams(-1, dp(54)));
        TextView start = text("▣ START", 16, Color.BLACK, true); start.setBackground(panel(0xffdededb, 0xff777777));
        taskbar.addView(start); start.setOnClickListener(v -> toggleDrawer());
        TextView brand = text("♡ PET HOME", 12, 0xff6c456f, true);
        taskbar.addView(brand, new LinearLayout.LayoutParams(0, -2, 1));
        battery = text("▣ --%", 11, Color.BLACK, true); taskbar.addView(battery);
        clock = text("--:--", 12, Color.BLACK, true); clock.setBackground(panel(0xffdededb, 0xff888888)); taskbar.addView(clock);
    }

    private JSONArray layout() {
        String saved = getSharedPreferences("launcher_layout", MODE_PRIVATE).getString("slots", "");
        if (!saved.isEmpty()) try { return new JSONArray(saved); } catch (Exception ignored) {}
        JSONArray initial = new JSONArray();
        for (int i=0;i<100;i++) initial.put("");
        putSlot(initial,0,"sys:apps"); putSlot(initial,1,"sys:settings");
        putSlot(initial,2,"sys:wallpaper"); putSlot(initial,3,"sys:folder");
        putSlot(initial,4,"sys:home");
        JSONObject f = readFolders(); Iterator<String> k = f.keys(); int slot=5;
        while (k.hasNext() && slot < initial.length()) putSlot(initial,slot++,"folder:"+k.next());
        persistLayout(initial); return initial;
    }
    private void putSlot(JSONArray arr, int idx, String value) {
        try { arr.put(idx,value); } catch (Exception ignored) {}
    }
    private void persistLayout(JSONArray arr) {
        getSharedPreferences("launcher_layout",MODE_PRIVATE).edit().putString("slots",arr.toString()).apply();
    }
    private String appLabel(String component) {
        String[] p = component.split("/",2);
        if (p.length < 2) return "APP";
        try { return pm.getActivityInfo(new android.content.ComponentName(p[0],p[1]),0).loadLabel(pm).toString(); }
        catch (Exception e) { return p[0]; }
    }
    private void renderDesktop() {
        if (desktopGrid == null) return;
        desktopGrid.removeAllViews(); desktopGrid.setColumnCount(columns);
        if (pageLabel != null) pageLabel.setText("DESKTOP " + (page+1) + "/" + totalPages);
        JSONArray slots = layout(); int capacity = columns * 4;
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int cellWidth = (screenWidth - dp(28)) / columns;
        for (int i=0;i<capacity;i++) {
            final int position = page * capacity + i;
            final String value = slots.optString(position, "");
            LinearLayout cell = new LinearLayout(this); cell.setOrientation(LinearLayout.VERTICAL);
            cell.setGravity(Gravity.CENTER); cell.setPadding(dp(2),dp(3),dp(2),dp(3));
            GridLayout.LayoutParams gp = new GridLayout.LayoutParams();
            gp.width = cellWidth; gp.height = dp(93); desktopGrid.addView(cell,gp);
            String glyph="+", label="";
            if (value.startsWith("sys:")) {
                String kind=value.substring(4);
                glyph=kind.equals("apps")?"▣":kind.equals("settings")?"⚙":kind.equals("folder")?"📁":kind.equals("home")?"⌂":"▤";
                label=kind.equals("apps")?"MY APPS":kind.equals("settings")?"SETTINGS":kind.equals("folder")?"NEW FOLDER":kind.equals("home")?"HOME DEFAULT":"WALLPAPER";
            } else if (value.startsWith("folder:")) { glyph="📁"; label=value.substring(7); }
            else if (value.startsWith("app:")) { label=appLabel(value.substring(4)); }
            if (value.startsWith("app:")) {
                String[] p = value.substring(4).split("/",2);
                ImageView icon = new ImageView(this);
                if (p.length==2) try { icon.setImageDrawable(pm.getActivityIcon(new android.content.ComponentName(p[0],p[1]))); } catch (Exception ignored) {}
                cell.addView(icon,new LinearLayout.LayoutParams(dp(42),dp(42)));
            } else {
                TextView icon=text(glyph,32,value.isEmpty()?0xff70a1a7:Color.WHITE,true);
                icon.setGravity(Gravity.CENTER); cell.addView(icon,new LinearLayout.LayoutParams(-1,dp(48)));
            }
            TextView caption=text(label,11,Color.WHITE,true); caption.setGravity(Gravity.TOP|Gravity.CENTER_HORIZONTAL);
            caption.setMaxLines(2); cell.addView(caption);
            cell.setOnClickListener(v -> openDesktopItem(value));
            if (!value.isEmpty()) cell.setOnLongClickListener(v -> {
                ClipData data = ClipData.newPlainText("nostaloom-slot", String.valueOf(position));
                v.startDragAndDrop(data,new View.DragShadowBuilder(v),null,0); return true;
            });
            cell.setOnDragListener((v,event) -> {
                if (event.getAction()==DragEvent.ACTION_DRAG_STARTED) return true;
                if (event.getAction()==DragEvent.ACTION_DRAG_ENTERED) { v.setBackgroundColor(0x6633ccff); return true; }
                if (event.getAction()==DragEvent.ACTION_DRAG_EXITED || event.getAction()==DragEvent.ACTION_DRAG_ENDED) { v.setBackgroundColor(Color.TRANSPARENT); return true; }
                if (event.getAction()==DragEvent.ACTION_DROP) {
                    try {
                        int from=Integer.parseInt(event.getClipData().getItemAt(0).getText().toString());
                        JSONArray arr=layout(); String dragged=arr.optString(from,""); String target=arr.optString(position,"");
                        if (from!=position && !dragged.isEmpty()) {
                            if (target.startsWith("folder:") && dragged.startsWith("app:")) {
                                addComponentToFolder(target.substring(7),dragged.substring(4));
                                putSlot(arr,from,"");
                            } else { putSlot(arr,position,dragged); putSlot(arr,from,target); }
                            persistLayout(arr); renderDesktop();
                        }
                    } catch (Exception ignored) {}
                    return true;
                }
                return true;
            });
        }
    }
    private void openDesktopItem(String value) {
        if (value.startsWith("folder:")) { openFolder(value.substring(7)); return; }
        if (value.startsWith("app:")) { launchComponent(value.substring(4)); return; }
        switch (value) {
            case "sys:apps": toggleDrawer(); break;
            case "sys:settings": launcherSettings(); break;
            case "sys:wallpaper": chooseWallpaper(); break;
            case "sys:folder": createFolder(); break;
            case "sys:home": chooseHome(); break;
        }
    }
    private void launchComponent(String component) {
        String[] p=component.split("/",2); if (p.length!=2) return;
        Intent intent=new Intent(Intent.ACTION_MAIN); intent.addCategory(Intent.CATEGORY_LAUNCHER);
        intent.setClassName(p[0],p[1]); intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
        try {
            startActivity(intent);
            SharedPreferences prefs=getSharedPreferences("launcher_options",MODE_PRIVATE);
            JSONArray old;
            try { old=new JSONArray(prefs.getString("recent","[]")); } catch (Exception e) { old=new JSONArray(); }
            JSONArray updated=new JSONArray(); updated.put(component);
            for (int i=0;i<old.length() && updated.length()<6;i++) if (!component.equals(old.optString(i))) updated.put(old.optString(i));
            prefs.edit().putString("recent",updated.toString()).apply();
        } catch (Exception e) { Toast.makeText(this,"Unable to open app",Toast.LENGTH_SHORT).show(); }
    }
    private void enablePageDrop(TextView button,int direction) {
        button.setOnDragListener((v,event) -> {
            if (event.getAction()==DragEvent.ACTION_DRAG_STARTED) return true;
            if (event.getAction()==DragEvent.ACTION_DRAG_ENTERED) { v.setBackgroundColor(0x6633ccff); return true; }
            if (event.getAction()==DragEvent.ACTION_DRAG_EXITED || event.getAction()==DragEvent.ACTION_DRAG_ENDED) { v.setBackgroundColor(Color.TRANSPARENT); return true; }
            if (event.getAction()==DragEvent.ACTION_DROP) {
                try {
                    int from=Integer.parseInt(event.getClipData().getItemAt(0).getText().toString());
                    JSONArray slots=layout(); String value=slots.optString(from,"");
                    int newPage=(page+totalPages+direction)%totalPages; int capacity=columns*4;
                    for (int i=0;i<capacity;i++) {
                        int dest=newPage*capacity+i;
                        if (slots.optString(dest,"").isEmpty()) {
                            putSlot(slots,dest,value); putSlot(slots,from,""); persistLayout(slots); break;
                        }
                    }
                    page=newPage; renderDesktop();
                } catch (Exception ignored) {}
                return true;
            }
            return true;
        });
    }
    private void launcherSettings() {
        String[] choices={"Choose animal friend", "Grid: 3 columns", "Grid: 4 columns", "Grid: 5 columns", "Pages: 3", "Pages: 5", "Android settings", "Choose default home", "Wallpaper"};
        new AlertDialog.Builder(this).setTitle("⚙ NOSTALOOM DISPLAY SETTINGS")
            .setItems(choices,(d,which)->{
                if (which==0) {choosePet();return;}
                if (which<=3) columns=which+2;
                else if (which==4) totalPages=3;
                else if (which==5) totalPages=5;
                else if (which==6) {openSettings();return;}
                else if (which==7) {chooseHome();return;}
                else {chooseWallpaper();return;}
                page=0;
                getSharedPreferences("launcher_options",MODE_PRIVATE).edit()
                    .putInt("columns",columns).putInt("pages",totalPages).apply();
                renderDesktop();
            }).setPositiveButton("CLOSE",null).show();
    }
    private void choosePet() {
        new AlertDialog.Builder(this).setTitle("♡ CHOOSE YOUR PET")
            .setSingleChoiceItems(new String[]{"Mochi the Cat", "Bunbun the Bunny", "Puffy the Puppy"},petType,
                (dialog,index)->{
                    petType=index; petMood=0;
                    getSharedPreferences("launcher_options",MODE_PRIVATE).edit().putInt("pet",petType).apply();
                    petMessage.setText(new String[]{"MEOW! ♡","BOING! ♡","WOOF! ♡"}[index]);
                    petView.invalidate(); dialog.dismiss();
                }).setNegativeButton("CANCEL",null).show();
    }
    private void interactPet() {
        new AlertDialog.Builder(this).setTitle(new String[]{"🐱 MOCHI", "🐰 BUNBUN", "🐶 PUFFY"}[petType])
            .setItems(new String[]{"♡ Pet & cuddle", "🍎 Feed", "★ Play", "☾ Sleep", "Change animal"},(dialog,action)->{
                if (action==4) { choosePet(); return; }
                petMood=action==3?2:1;
                petMessage.setText(new String[]{"LOVE YOU! ♡", "YUMMY! ♡", "LET'S PLAY! ★", "Zzz... ☾"}[action]);
                petView.invalidate();
                if (action==2 || action==0) petView.animate().translationY(-dp(15)).setDuration(190)
                    .withEndAction(()->petView.animate().translationY(0).setDuration(280).start()).start();
                if (action==3) petView.animate().rotation(-9).setDuration(350).start();
                else petView.animate().rotation(0).setDuration(200).start();
                handler.postDelayed(()->{
                    petMood=0;
                    if (petMessage!=null) petMessage.setText("♡ TAP ME!");
                    if (petView!=null) {petView.animate().rotation(0).setDuration(180).start();petView.invalidate();}
                },4500);
            }).show();
    }
    private class PetView extends View {
        private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
        PetView() { super(LauncherActivity.this); setLayerType(View.LAYER_TYPE_SOFTWARE,null); }
        private void fill(Canvas c,int color) {paint.setColor(color);paint.setStyle(Paint.Style.FILL);}
        private void ellipse(Canvas c,float x1,float y1,float x2,float y2,int color) {
            fill(c,color);c.drawOval(x1,y1,x2,y2,paint);
        }
        private void circle(Canvas c,float x,float y,float r,int color) {
            fill(c,color);c.drawCircle(x,y,r,paint);
        }
        @Override protected void onDraw(Canvas original) {
            super.onDraw(original);
            Canvas c=original;
            c.save();c.scale(getWidth()/140f,getHeight()/150f);
            int fur=petType==0?0xffffe7c8:petType==1?0xfffbf5f2:0xffdfb38d;
            int accent=petType==0?0xffd9a985:petType==1?0xffeaa6b9:0xffac765c;
            ellipse(c,23,103,117,150,0x448f5d7d);
            ellipse(c,35,87,107,143,fur);
            if (petType==0) {
                Path left=new Path();left.moveTo(24,54);left.lineTo(27,8);left.lineTo(61,28);left.close();
                fill(c,fur);c.drawPath(left,paint);
                Path right=new Path();right.moveTo(79,29);right.lineTo(113,8);right.lineTo(115,55);right.close();c.drawPath(right,paint);
                Path inner=new Path();inner.moveTo(32,47);inner.lineTo(33,21);inner.lineTo(53,32);inner.close();fill(c,accent);c.drawPath(inner,paint);
                inner=new Path();inner.moveTo(86,32);inner.lineTo(107,21);inner.lineTo(108,48);inner.close();c.drawPath(inner,paint);
            } else if (petType==1) {
                ellipse(c,34,0,56,66,fur);ellipse(c,84,0,106,66,fur);
                ellipse(c,40,9,50,57,accent);ellipse(c,90,9,100,57,accent);
            } else {
                ellipse(c,12,33,55,98,accent);ellipse(c,86,33,128,98,accent);
            }
            circle(c,70,72,52,fur);
            ellipse(c,35,92,55,104,0xfff7a3ae);ellipse(c,85,92,105,104,0xfff7a3ae);
            if (petMood==2) {
                fill(c,0xff47384e);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(3);
                c.drawArc(40,67,58,77,0,180,false,paint);c.drawArc(82,67,100,77,0,180,false,paint);
                paint.setStyle(Paint.Style.FILL);
            } else if (petMood==1) {
                ellipse(c,40,65,58,77,0xff493b4c);ellipse(c,82,65,100,77,0xff493b4c);
                circle(c,49,68,3,Color.WHITE);circle(c,91,68,3,Color.WHITE);
            } else {
                ellipse(c,40,62,56,84,0xff493b4c);ellipse(c,84,62,100,84,0xff493b4c);
                circle(c,49,68,4,Color.WHITE);circle(c,93,68,4,Color.WHITE);
            }
            ellipse(c,65,84,75,91,0xff8a5967);
            fill(c,0xff8a5967);paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(2.5f);
            c.drawArc(59,86,70,99,0,150,false,paint);c.drawArc(70,86,81,99,30,150,false,paint);
            paint.setStyle(Paint.Style.FILL);
            ellipse(c,44,126,65,141,fur);ellipse(c,76,126,97,141,fur);
            c.restore();
        }
    }
    private void toggleDrawer() {
        drawerVisible = !drawerVisible;
        drawer.setVisibility(drawerVisible ? View.VISIBLE : View.GONE);
        if (drawerVisible) { loadApps(); populate(search.getText().toString()); }
    }
    private void loadApps() {
        Intent i = new Intent(Intent.ACTION_MAIN); i.addCategory(Intent.CATEGORY_LAUNCHER);
        apps.clear(); apps.addAll(pm.queryIntentActivities(i, 0));
        Collections.sort(apps, Comparator.comparing(a -> a.loadLabel(pm).toString().toLowerCase(Locale.getDefault())));
    }
    private void populate(String filter) {
        appList.removeAllViews();
        String q = filter.toLowerCase(Locale.getDefault()).trim();
        if (q.isEmpty()) {
            SharedPreferences prefs=getSharedPreferences("launcher_options",MODE_PRIVATE);
            showQuickList("★ FAVORITES",prefs.getString("favorites","[]"));
            showQuickList("◷ RECENT",prefs.getString("recent","[]"));
            TextView all=text("▣ ALL PROGRAMS",14,Color.WHITE,true); all.setBackgroundColor(0xff101e77); appList.addView(all);
        }
        for (ResolveInfo info : apps) {
            String name = info.loadLabel(pm).toString();
            if (!name.toLowerCase(Locale.getDefault()).contains(q)) continue;
            LinearLayout row = new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
            row.setPadding(dp(8), dp(5), dp(8), dp(5));
            ImageView icon = new ImageView(this); icon.setImageDrawable(info.loadIcon(pm));
            row.addView(icon, new LinearLayout.LayoutParams(dp(34),dp(34)));
            TextView label = text(name, 15, Color.BLACK, false);
            row.addView(label, new LinearLayout.LayoutParams(0,dp(48),1));
            appList.addView(row);
            row.setOnClickListener(v -> launchComponent(info.activityInfo.packageName + "/" + info.activityInfo.name));
            row.setOnLongClickListener(v -> { chooseAddLocation(info); return true; });
        }
        if (appList.getChildCount() == 0) appList.addView(text("No matching apps", 15, Color.BLACK, false));
    }
    private void showQuickList(String heading,String json) {
        JSONArray arr;
        try { arr=new JSONArray(json); } catch (Exception e) { return; }
        if (arr.length()==0) return;
        TextView title=text(heading,13,Color.WHITE,true); title.setBackgroundColor(0xff34516e); appList.addView(title);
        for (int i=0;i<arr.length();i++) {
            final String component=arr.optString(i);
            TextView item=text("  ▸ " + appLabel(component),14,Color.BLACK,false);
            appList.addView(item); item.setOnClickListener(v -> launchComponent(component));
        }
    }
    private void openSettings() { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch (Exception ignored) {} }
    private void chooseHome() {
        try { startActivity(new Intent(Settings.ACTION_HOME_SETTINGS)); }
        catch (ActivityNotFoundException e) { Toast.makeText(this,"Choose default launcher in phone settings",Toast.LENGTH_LONG).show(); }
    }
    private void chooseWallpaper() {
        try { startActivity(new Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)); }
        catch (Exception e) { try { startActivity(new Intent(Intent.ACTION_SET_WALLPAPER)); } catch (Exception ignored) {} }
    }
    private JSONObject readFolders() {
        SharedPreferences prefs = getSharedPreferences("desktop_folders", MODE_PRIVATE);
        try { return new JSONObject(prefs.getString("folders", "{}")); }
        catch (Exception e) { return new JSONObject(); }
    }
    private void saveFolders(JSONObject folders) {
        getSharedPreferences("desktop_folders", MODE_PRIVATE).edit().putString("folders", folders.toString()).apply();
        refreshFolders();
    }
    private void createFolder() {
        EditText name = new EditText(this); name.setSingleLine(true); name.setHint("Folder name");
        new AlertDialog.Builder(this).setTitle("CREATE DESKTOP FOLDER").setView(name)
            .setNegativeButton("CANCEL", null).setPositiveButton("CREATE", (d, w) -> {
                String label = name.getText().toString().trim();
                if (label.isEmpty()) label = "My Folder";
                JSONObject folders = readFolders();
                if (folders.has(label)) { Toast.makeText(this, "Folder already exists", Toast.LENGTH_SHORT).show(); return; }
                try {
                    JSONArray slots=layout(); boolean placed=false;
                    for (int i=0;i<totalPages*columns*4;i++) if (slots.optString(i,"").isEmpty()) {
                        putSlot(slots,i,"folder:"+label); placed=true; break;
                    }
                    if (!placed) { Toast.makeText(this,"No free desktop slot",Toast.LENGTH_LONG).show(); return; }
                    folders.put(label,new JSONArray()); persistLayout(slots); saveFolders(folders);
                } catch (Exception ignored) {}
            }).show();
    }
    private void refreshFolders() { renderDesktop(); }
    private void chooseAddLocation(ResolveInfo info) {
        new AlertDialog.Builder(this).setTitle(info.loadLabel(pm))
            .setItems(new String[]{"Add to desktop", "Add to folder", "Toggle favorite"}, (d,which)->{
                if (which==0) addAppToDesktop(info);
                else if (which==1) addAppToFolder(info);
                else toggleFavorite(info.activityInfo.packageName+"/"+info.activityInfo.name);
            }).show();
    }
    private void toggleFavorite(String component) {
        SharedPreferences prefs=getSharedPreferences("launcher_options",MODE_PRIVATE);
        JSONArray old; try {old=new JSONArray(prefs.getString("favorites","[]"));} catch(Exception e){old=new JSONArray();}
        JSONArray updated=new JSONArray(); boolean found=false;
        for (int i=0;i<old.length();i++) {
            String x=old.optString(i); if (x.equals(component)) found=true; else updated.put(x);
        }
        if (!found) updated.put(component);
        prefs.edit().putString("favorites",updated.toString()).apply();
        Toast.makeText(this,found?"Removed favorite":"Favorite saved",Toast.LENGTH_SHORT).show();
        populate(search.getText().toString());
    }
    private void addAppToDesktop(ResolveInfo info) {
        String component="app:"+info.activityInfo.packageName+"/"+info.activityInfo.name;
        JSONArray slots=layout(); int capacity=columns*4;
        for (int i=0;i<totalPages*capacity;i++) {
            if (component.equals(slots.optString(i))) { Toast.makeText(this,"Already on desktop",Toast.LENGTH_SHORT).show(); return; }
        }
        for (int i=page*capacity;i<(page+1)*capacity;i++) {
            if (slots.optString(i,"").isEmpty()) {
                putSlot(slots,i,component); persistLayout(slots); renderDesktop();
                if (drawerVisible) toggleDrawer(); return;
            }
        }
        Toast.makeText(this,"Page full. Switch to another desktop page.",Toast.LENGTH_LONG).show();
    }
    private void addComponentToFolder(String name, String component) {
        JSONObject f=readFolders(); JSONArray entries=f.optJSONArray(name);
        if (entries==null) return;
        for (int i=0;i<entries.length();i++) if (component.equals(entries.optString(i))) return;
        entries.put(component); saveFolders(f);
    }
    private void addAppToFolder(ResolveInfo info) {
        JSONObject folders = readFolders(); JSONArray names = folders.names();
        if (names == null || names.length() == 0) {
            Toast.makeText(this, "Create a desktop folder first", Toast.LENGTH_LONG).show(); return;
        }
        String[] options = new String[names.length()];
        for (int i=0;i<options.length;i++) options[i] = names.optString(i);
        new AlertDialog.Builder(this).setTitle("ADD TO FOLDER: " + info.loadLabel(pm))
            .setItems(options, (d, which) -> {
                JSONObject f = readFolders(); JSONArray entries = f.optJSONArray(options[which]);
                String component = info.activityInfo.packageName + "/" + info.activityInfo.name;
                if (entries != null) {
                    for (int i=0;i<entries.length();i++) if (component.equals(entries.optString(i))) return;
                    addComponentToFolder(options[which],component);
                    Toast.makeText(this, "Added to " + options[which], Toast.LENGTH_SHORT).show();
                }
            }).show();
    }
    private void openFolder(String name) {
        JSONArray entries = readFolders().optJSONArray(name);
        if (entries == null) return;
        List<String> labels = new ArrayList<>(); List<String> components = new ArrayList<>();
        for (int i=0;i<entries.length();i++) {
            String component = entries.optString(i); String[] parts = component.split("/",2);
            if (parts.length != 2) continue;
            try {
                String label = pm.getActivityInfo(new android.content.ComponentName(parts[0],parts[1]),0).loadLabel(pm).toString();
                labels.add(label); components.add(component);
            } catch (Exception ignored) {}
        }
        if (labels.isEmpty()) { new AlertDialog.Builder(this).setTitle(name).setMessage("Folder empty. Open MY APPS and long-press an app to add it.").setPositiveButton("MANAGE",(d,w)->manageFolder(name)).setNegativeButton("CLOSE",null).show(); return; }
        new AlertDialog.Builder(this).setTitle("▣ " + name).setItems(labels.toArray(new String[0]), (d, which) -> {
            String[] parts = components.get(which).split("/", 2);
            Intent launch = new Intent(Intent.ACTION_MAIN); launch.addCategory(Intent.CATEGORY_LAUNCHER);
            launch.setClassName(parts[0],parts[1]); launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try { startActivity(launch); } catch (Exception e) { Toast.makeText(this,"Cannot open app",Toast.LENGTH_SHORT).show(); }
        }).setNeutralButton("REMOVE APP", (d, w) -> removeFromFolder(name, labels, components))
          .setPositiveButton("MANAGE",(d,w)->manageFolder(name)).show();
    }
    private void manageFolder(String name) {
        new AlertDialog.Builder(this).setTitle("MANAGE " + name)
            .setItems(new String[]{"Rename folder", "Delete folder"},(d,which)->{
                if (which==0) {
                    EditText input=new EditText(this); input.setSingleLine(true); input.setText(name);
                    new AlertDialog.Builder(this).setTitle("RENAME FOLDER").setView(input)
                        .setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(dialog,button)->{
                            String renamed=input.getText().toString().trim();
                            if (renamed.isEmpty() || renamed.equals(name)) return;
                            JSONObject folders=readFolders();
                            if (folders.has(renamed)) { Toast.makeText(this,"Name already exists",Toast.LENGTH_SHORT).show(); return; }
                            JSONArray arr=folders.optJSONArray(name); folders.remove(name);
                            try {folders.put(renamed,arr);}catch(Exception ignored){}
                            JSONArray slots=layout();
                            for (int i=0;i<slots.length();i++) if (slots.optString(i).equals("folder:"+name)) putSlot(slots,i,"folder:"+renamed);
                            persistLayout(slots);saveFolders(folders);
                        }).show();
                } else {
                    new AlertDialog.Builder(this).setTitle("DELETE " + name)
                        .setMessage("Only the folder is removed. Installed applications remain safe.")
                        .setNegativeButton("CANCEL",null).setPositiveButton("DELETE",(dialog,button)->{
                            JSONObject folders=readFolders();folders.remove(name);
                            JSONArray slots=layout();
                            for (int i=0;i<slots.length();i++) if (slots.optString(i).equals("folder:"+name)) putSlot(slots,i,"");
                            persistLayout(slots);saveFolders(folders);
                        }).show();
                }
            }).show();
    }
    private void removeFromFolder(String name, List<String> labels, List<String> components) {
        new AlertDialog.Builder(this).setTitle("REMOVE FROM " + name).setItems(labels.toArray(new String[0]), (d, which) -> {
            JSONObject f = readFolders(); JSONArray old = f.optJSONArray(name); JSONArray updated = new JSONArray();
            if (old != null) for (int i=0;i<old.length();i++) if (!components.get(which).equals(old.optString(i))) updated.put(old.optString(i));
            try { f.put(name, updated); saveFolders(f); } catch (Exception ignored) {}
        }).show();
    }
    @Override public void onBackPressed() { if (drawerVisible) toggleDrawer(); else super.onBackPressed(); }
    @Override protected void onDestroy() { handler.removeCallbacksAndMessages(null); super.onDestroy(); }
}
