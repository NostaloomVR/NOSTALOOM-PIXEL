package com.mygamestudio.nostaloomlauncher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

final class PixelHomeView extends ViewGroup {
    private static final int ART_WIDTH = 540;
    private static final int ART_HEIGHT = 1170;
    private static final int INK = 0xff3b2b4d;
    private static final int PAPER = 0xffd0c6bb;
    private static final Typeface PIXEL_TEXT = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD);

    private final Bitmap artwork;
    private final Paint artworkPaint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final RectF artBounds = new RectF(0, 0, ART_WIDTH, ART_HEIGHT);

    PixelHomeView(Context context) {
        super(context);
        artwork = BitmapFactory.decodeResource(getResources(), R.drawable.cozy_home);
        setWillNotDraw(false);
        setBackgroundColor(0xff529a91);
    }

    void place(View view, int left, int top, int width, int height) {
        addView(view, new Position(left, top, width, height));
    }

    @Override protected void onMeasure(int widthSpec, int heightSpec) {
        int width = MeasureSpec.getSize(widthSpec);
        int height = MeasureSpec.getSize(heightSpec);
        setMeasuredDimension(width, height);
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            Position pos = (Position) child.getLayoutParams();
            int left = scale(pos.left, width, ART_WIDTH);
            int top = scale(pos.top, height, ART_HEIGHT);
            int right = scale(pos.left + pos.width, width, ART_WIDTH);
            int bottom = scale(pos.top + pos.height, height, ART_HEIGHT);
            child.measure(MeasureSpec.makeMeasureSpec(right - left, MeasureSpec.EXACTLY),
                MeasureSpec.makeMeasureSpec(bottom - top, MeasureSpec.EXACTLY));
        }
    }

    @Override protected void onLayout(boolean changed, int left, int top, int right, int bottom) {
        for (int i = 0; i < getChildCount(); i++) {
            View child = getChildAt(i);
            Position pos = (Position) child.getLayoutParams();
            int x = scale(pos.left, getWidth(), ART_WIDTH);
            int y = scale(pos.top, getHeight(), ART_HEIGHT);
            child.layout(x, y, x + child.getMeasuredWidth(), y + child.getMeasuredHeight());
        }
    }

    @Override protected void onDraw(Canvas canvas) {
        canvas.save();
        canvas.scale(getWidth() / (float) ART_WIDTH, getHeight() / (float) ART_HEIGHT);
        canvas.drawBitmap(artwork, null, artBounds, artworkPaint);
        canvas.restore();
    }

    private static int scale(int coordinate, int actual, int reference) {
        return Math.round(coordinate * (float) actual / reference);
    }

    private static final class Position extends ViewGroup.LayoutParams {
        final int left;
        final int top;

        Position(int left, int top, int width, int height) {
            super(width, height);
            this.left = left;
            this.top = top;
        }
    }

    abstract static class ArtworkView extends View {
        final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final float width;
        private final float height;

        ArtworkView(Context context, int width, int height) {
            super(context);
            this.width = width;
            this.height = height;
        }

        @Override protected final void onDraw(Canvas canvas) {
            canvas.save();
            canvas.scale(getWidth() / width, getHeight() / height);
            drawArtwork(canvas);
            canvas.restore();
        }

        abstract void drawArtwork(Canvas canvas);

        void text(Canvas canvas, String value, float x, float y, float size,
                int color, Paint.Align align) {
            paint.setTypeface(PIXEL_TEXT);
            paint.setTextSize(size);
            paint.setColor(color);
            paint.setTextAlign(align);
            canvas.drawText(value, x, y, paint);
        }
    }

    static final class DotClock extends ArtworkView {
        private static final int[][] DIGITS = {
            {14, 17, 19, 21, 25, 17, 14},
            {4, 12, 4, 4, 4, 4, 14},
            {14, 17, 1, 2, 4, 8, 31},
            {30, 1, 1, 14, 1, 1, 30},
            {2, 6, 10, 18, 31, 2, 2},
            {31, 16, 16, 30, 1, 1, 30},
            {14, 16, 16, 30, 17, 17, 14},
            {31, 1, 2, 4, 8, 8, 8},
            {14, 17, 17, 14, 17, 17, 14},
            {14, 17, 17, 15, 1, 1, 14}
        };
        private static final int[] DIGIT_COLUMNS = {2, 8, 16, 22};
        private final int[] rows = new int[7];
        private String time = "";

        DotClock(Context context) {
            super(context, 198, 77);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        }

        void setTime(String next) {
            if (time.equals(next)) return;
            time = next;
            for (int row = 0; row < rows.length; row++) {
                int bits = 0;
                for (int digit = 0; digit < DIGIT_COLUMNS.length; digit++) {
                    int index = digit < 2 ? digit : digit + 1;
                    int value = next.charAt(index) - '0';
                    for (int col = 0; col < 5; col++) {
                        if ((DIGITS[value][row] & (16 >> col)) != 0) {
                            bits |= 1 << (DIGIT_COLUMNS[digit] + col);
                        }
                    }
                }
                if (row == 2 || row == 4) bits |= 1 << 14;
                rows[row] = bits;
            }
            setContentDescription("Jam " + time);
            invalidate();
        }

        @Override void drawArtwork(Canvas canvas) {
            paint.setColor(0xff171019);
            canvas.drawRoundRect(0, 0, 198, 77, 8, 8, paint);
            paint.setColor(0xff2b1b36);
            canvas.drawRoundRect(2, 2, 196, 75, 7, 7, paint);
            paint.setColor(0xff100d14);
            canvas.drawRoundRect(4, 4, 194, 73, 5, 5, paint);

            for (int row = 0; row < 9; row++) {
                int mask = row == 0 || row == 8 ? 0 : rows[row - 1];
                for (int col = 0; col < 29; col++) {
                    float x = 12.2f + 6.2f * col;
                    float y = 13.5f + 6.25f * row;
                    boolean lit = (mask & (1 << col)) != 0;
                    paint.setColor(lit ? 0xffd598ff : 0xff30203e);
                    canvas.drawCircle(x, y, lit ? 2.28f : 1.28f, paint);
                    if (lit) {
                        paint.setColor(0xffeac8ff);
                        canvas.drawCircle(x - .52f, y - .56f, .72f, paint);
                    }
                }
            }
        }
    }

    static final class DeviceLine extends ArtworkView {
        private final Shader backdrop = new LinearGradient(0, 0, 540, 0,
            new int[]{0xff539990, 0xff50958d, 0xff4a8e85}, null, Shader.TileMode.CLAMP);
        private String time = "";
        private int battery = -1;

        DeviceLine(Context context) {
            super(context, 540, 34);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_NO);
        }

        void setValues(String nextTime, int nextBattery) {
            if (time.equals(nextTime) && battery == nextBattery) return;
            time = nextTime;
            battery = nextBattery;
            invalidate();
        }

        @Override void drawArtwork(Canvas canvas) {
            paint.setShader(backdrop);
            canvas.drawRect(0, 0, 540, 34, paint);
            paint.setShader(null);

            int dark = 0xff143f3b;
            text(canvas, time, 24, 23, 16, dark, Paint.Align.LEFT);
            paint.setColor(dark);
            canvas.drawRoundRect(459, 10, 486, 25, 3, 3, paint);
            canvas.drawRect(486, 14, 490, 21, paint);
            paint.setColor(0xff70ad9d);
            canvas.drawRoundRect(461, 12, 484, 23, 1, 1, paint);
            if (battery >= 0) {
                paint.setColor(dark);
                canvas.drawRect(462, 13, 462 + 21 * battery / 100f, 22, paint);
                text(canvas, battery + "%", 522, 23, 13, dark, Paint.Align.RIGHT);
            }
        }
    }

    static final class DatePlate extends ArtworkView {
        private String value = "";

        DatePlate(Context context) {
            super(context, 124, 29);
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
        }

        void setDate(String date) {
            if (value.equals(date)) return;
            value = date;
            setContentDescription(date);
            invalidate();
        }

        @Override void drawArtwork(Canvas canvas) {
            paint.setColor(0xffae98c0);
            canvas.drawRoundRect(0, 0, 124, 29, 6, 6, paint);
            text(canvas, value, 61, 21, 16, INK, Paint.Align.CENTER);
        }
    }

    static final class Fruit extends ArtworkView {
        private final SocialApp app;
        private final Path leaf = new Path();
        private int count = Integer.MIN_VALUE;

        Fruit(Context context, SocialApp app) {
            super(context, 46, 54);
            this.app = app;
            leaf.moveTo(23, 13);
            leaf.lineTo(27, 6);
            leaf.lineTo(36, 5);
            leaf.lineTo(34, 12);
            leaf.lineTo(29, 15);
            leaf.close();
            setCount(-1);
        }

        void setCount(int next) {
            if (count == next) return;
            count = next;
            setContentDescription(app.label + (count < 0
                ? ", kiraan belum tersedia" : ", " + count + " notifikasi aktif"));
            invalidate();
        }

        @Override public CharSequence getAccessibilityClassName() {
            return Button.class.getName();
        }

        @Override void drawArtwork(Canvas canvas) {
            paint.setColor(0xff422a3f);
            canvas.drawRoundRect(19, 6, 24, 25, 2, 2, paint);
            canvas.drawPath(leaf, paint);
            paint.setColor(0xff75a959);
            canvas.drawOval(26, 8, 34, 13, paint);
            paint.setColor(app.shade);
            canvas.drawCircle(23, 34, 16.5f, paint);
            paint.setColor(app.color);
            canvas.drawCircle(22, 32, 13.4f, paint);
            paint.setColor(0x92ffffff);
            canvas.drawRoundRect(13, 22, 18.5f, 25.6f, 1, 1, paint);

            String number = count < 0 ? "–" : count > 99 ? "99+" : Integer.toString(count);
            float size = number.length() > 2 ? 12 : 16;
            text(canvas, number, 23, 40, size, app.shade, Paint.Align.CENTER);
            text(canvas, number, 23, 38.5f, size, Color.WHITE, Paint.Align.CENTER);
        }
    }

    static final class PetPanel extends ArtworkView {
        private final MochiCare pet;
        private String state = "Mochi";

        PetPanel(Context context, MochiCare pet) {
            super(context, 230, 131);
            this.pet = pet;
            setImportantForAccessibility(IMPORTANT_FOR_ACCESSIBILITY_YES);
            refresh("Mochi");
        }

        void refresh(String nextState) {
            state = nextState;
            setContentDescription("Mochi. Gembira " + pet.happiness + " peratus. Kenyang "
                + pet.fullness + " peratus. Tenaga " + pet.energy + " peratus. " + state);
            invalidate();
        }

        @Override void drawArtwork(Canvas canvas) {
            paint.setColor(PAPER);
            canvas.drawRect(0, 0, 230, 122, paint);
            canvas.drawRoundRect(0, 110, 230, 131, 8, 8, paint);
            meter(canvas, "GEMBIRA", pet.happiness, 15, 0xffc06e91);
            meter(canvas, "KENYANG", pet.fullness, 41, 0xffd9a75a);
            meter(canvas, "TENAGA", pet.energy, 67, 0xff9a78c7);
            text(canvas, state, 13, 94, 12, INK, Paint.Align.LEFT);
        }

        private void meter(Canvas canvas, String name, int value, int y, int color) {
            text(canvas, name, 13, y, 13, INK, Paint.Align.LEFT);
            text(canvas, value + "%", 219, y, 13, INK, Paint.Align.RIGHT);
            paint.setColor(INK);
            canvas.drawRoundRect(13, y + 5, 220, y + 15, 4, 4, paint);
            paint.setColor(0xffbdb0ba);
            canvas.drawRoundRect(15, y + 7, 218, y + 13, 3, 3, paint);
            if (value > 0) {
                paint.setColor(color);
                canvas.drawRoundRect(15, y + 7, 15 + 203 * value / 100f, y + 13, 3, 3, paint);
            }
        }
    }

    static final class PetButton extends ArtworkView {
        private final int width;
        private final boolean food;

        PetButton(Context context, int width, boolean food) {
            super(context, width, 38);
            this.width = width;
            this.food = food;
            setContentDescription(food ? "Beri Makan" : "Main");
        }

        @Override public CharSequence getAccessibilityClassName() {
            return Button.class.getName();
        }

        @Override public void setPressed(boolean pressed) {
            super.setPressed(pressed);
            invalidate();
        }

        @Override void drawArtwork(Canvas canvas) {
            paint.setColor(INK);
            canvas.drawRoundRect(1, 3, width - 1, 37, 8, 8, paint);
            paint.setColor(isPressed() ? 0xffaa8ec4 : food ? 0xfff1d6c8 : 0xffdac9ed);
            canvas.drawRoundRect(3, 5, width - 3, 34, 6, 6, paint);
            if (food) {
                drawBowl(canvas, paint, 18, 23, .62f);
            } else {
                drawYarn(canvas, paint, 17, 20, .75f);
            }
            text(canvas, food ? "Beri Makan" : "Main", (width + 22) / 2f, 24,
                food ? 13.5f : 15, INK, Paint.Align.CENTER);
        }
    }

    static void drawBowl(Canvas canvas, Paint paint, float x, float y, float scale) {
        canvas.save();
        canvas.translate(x, y);
        canvas.scale(scale, scale);
        paint.setColor(INK);
        canvas.drawRoundRect(-14, -7, 14, 7, 4, 4, paint);
        canvas.drawOval(-12, -12, 12, -3, paint);
        paint.setColor(0xffd2828f);
        canvas.drawRoundRect(-12, -5, 12, 5, 3, 3, paint);
        paint.setColor(0xffc78649);
        canvas.drawOval(-10, -10, 10, -4, paint);
        paint.setColor(0xffffddaf);
        canvas.drawRect(-6, -9, -2, -7, paint);
        canvas.drawRect(2, -8, 6, -6, paint);
        paint.setColor(0xffffebdc);
        canvas.drawRect(-2, 0, 2, 3, paint);
        canvas.restore();
    }

    static void drawYarn(Canvas canvas, Paint paint, float x, float y, float scale) {
        canvas.save();
        canvas.translate(x, y);
        canvas.scale(scale, scale);
        paint.setColor(INK);
        paint.setStrokeWidth(2);
        canvas.drawLine(0, 7, 10, 10, paint);
        canvas.drawLine(10, 10, 14, 8, paint);
        canvas.drawCircle(0, 0, 10, paint);
        paint.setColor(0xffae85ce);
        canvas.drawCircle(0, 0, 8, paint);
        paint.setColor(0xff6a468c);
        paint.setStrokeWidth(1.2f);
        canvas.drawLine(-7, -3, 4, 6, paint);
        canvas.drawLine(-4, -6, 7, 3, paint);
        canvas.drawLine(3, -7, -5, 5, paint);
        canvas.restore();
    }
}
