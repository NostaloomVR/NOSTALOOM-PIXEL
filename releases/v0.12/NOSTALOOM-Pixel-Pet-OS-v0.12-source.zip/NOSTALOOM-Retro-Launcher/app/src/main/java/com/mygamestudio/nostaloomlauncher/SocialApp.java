package com.mygamestudio.nostaloomlauncher;

enum SocialApp {
    TIKTOK("tiktok", "TikTok", 0xffa259cc, 0xff57317c, "https://www.tiktok.com/",
        "com.zhiliaoapp.musically", "com.ss.android.ugc.trill", "com.zhiliaoapp.musically.go"),
    YOUTUBE("youtube", "YouTube", 0xffe3515d, 0xff922d42, "https://www.youtube.com/",
        "com.google.android.youtube"),
    WHATSAPP("whatsapp", "WhatsApp", 0xff69a940, 0xff315f32, "https://www.whatsapp.com/",
        "com.whatsapp", "com.whatsapp.w4b"),
    FACEBOOK("facebook", "Facebook", 0xff4f8fe2, 0xff2d4d94, "https://www.facebook.com/",
        "com.facebook.katana", "com.facebook.lite", "com.facebook.orca");

    final String tabId;
    final String label;
    final int color;
    final int shade;
    final String website;
    final String[] packages;

    SocialApp(String tabId, String label, int color, int shade, String website, String... packages) {
        this.tabId = tabId;
        this.label = label;
        this.color = color;
        this.shade = shade;
        this.website = website;
        this.packages = packages;
    }

    static SocialApp fromPackage(String packageName) {
        for (SocialApp app : values()) {
            for (String candidate : app.packages) {
                if (candidate.equals(packageName)) return app;
            }
        }
        return null;
    }

    static SocialApp fromTab(String tabId) {
        for (SocialApp app : values()) {
            if (app.tabId.equals(tabId)) return app;
        }
        return null;
    }
}
