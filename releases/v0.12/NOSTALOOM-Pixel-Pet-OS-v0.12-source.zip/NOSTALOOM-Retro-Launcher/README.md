# NOSTALOOM Pixel Pet OS v0.12

Android launcher with the floating-island home, an animated pet, and a purple dot-matrix clock. The clock uses the phone's local time. The weather illustration comes from the background artwork.

## Buah notifikasi

| Warna | Aplikasi |
| --- | --- |
| Ungu | TikTok |
| Merah | YouTube |
| Hijau | WhatsApp |
| Biru | Facebook dan Messenger |

Ketik buah dan pilih **Buka Tetapan**, kemudian aktifkan **Akses Notifikasi** untuk **NOSTALOOM Pixel Pet OS 0.12**. Buah menunjukkan bilangan notifikasi Android yang masih aktif. Jika Android kumpulkan beberapa mesej menjadi satu notifikasi, kiraan ikut notifikasi itu. Angka turun apabila notifikasi dibuang. Nombor 0 bermakna tiada notifikasi aktif, sementara tanda sengkang bermakna kiraan belum tersedia. Aplikasi menyimpan kiraan dalam memori peranti dan tidak merekod isi notifikasi.

## Mochi

- **Beri Makan** memanggil Mochi ke mangkuk, kemudian menambah bar kenyang.
- **Main** menggerakkan Mochi mengejar bola benang dan menggunakan sedikit tenaga.
- Ketik Mochi di pulau untuk belai. Tekan lama atau ketik potret Mochi untuk membuka menu termasuk **Rehat**.
- Mochi berjalan dan duduk sendiri. Gembira, kenyang dan tenaga disimpan pada telefon.

Ketik ikon grid di dok untuk laci aplikasi. Tekan lama ikon itu atau pilih **Menu Launcher** dalam laci untuk pilihan launcher, folder dan Classic Cute Desktop. Tekan lama ikon media sosial di sisi untuk buka dan susun semula sembilan **Tab Sisi**.

## Build and install

Use Android Studio or Gradle 8.2 with JDK 17 and Android SDK Platform 34. Run `gradle assembleDebug` from the project root. The APK is at `app/build/outputs/apk/debug/app-debug.apk`. The source targets Android 14 and supports Android 6 or newer.

This debug APK has a distinct application ID so it can install alongside v0.11, which used a different signing certificate. Choose **NOSTALOOM Pixel Pet OS 0.12** as the Home app in Android Settings if desired. The new installation has its own settings and pet progress.

## Earlier versions

### Right-edge tape tabs (v0.11)

The Pixel Village now has nine colorful ripped-paper-style side tabs inspired by the supplied phone screenshot: Facebook, YouTube, TikTok, Chrome, Explorer, WhatsApp, Galeri, Camera and Lockscreen. Tap to open the installed app or supported Android intent, or long-press and drag one tab onto another to exchange their order; ordering persists locally. The Lockscreen tab opens Android security settings only — unprivileged launchers cannot forcibly lock the screen without additional device-admin permissions. The social app shortcuts fall back to relevant websites when the app is absent. The background scene and Mochi interactions remain.

### Pixel Village Home (v0.10)

A new pixel-art Android HOME activity uses the NOSTALOOM Pixel Pet OS concept artwork as its full-screen scene. Interactive touch areas map to the Camera, Music, Gallery, Chat, Web, Settings and Files locations. The bottom pixel taskbar has functioning START, HOME, PET and APPS regions. A small right-edge social rail offers WhatsApp, Facebook, YouTube and TikTok, with browser fallback when the app isn't installed. Mochi responds to feeding, play, petting and sleep through a live speech bubble and saved heart count. Dynamic clock and battery information cover the concept artwork's static top status. START provides the real searchable app list, folders and an option to enter the prior Cute Desktop mode, retaining its folder and icon-layout data. Background weather is decorative pixel art, not live weather data.

The artwork is a static bitmap; the individual buildings themselves do not animate in this version. On a phone with a significantly different aspect ratio, hotspot locations may require calibration. This is a debug test build, not a production launcher.

Native Java Android HOME launcher for Redmi Note 8 / Android 10, with a Windows 98 Enhanced-inspired desktop, drag-and-drop shortcut grid (including swapping icons and dropping apps into folders), three or five desktop pages, three-to-five column settings, searchable START menu, recent/favorite applications, customizable persistent desktop folders, bottom taskbar clock and battery indicator, system settings and wallpaper shortcuts. The system status bar is hidden while in the launcher (the actual Android status bar is not moved).

### Cute Animal mode (v0.04)

The home screen now uses a soft pastel theme and a vector-rendered desktop animal. Choose Mochi the cat, Bunbun the bunny, or Puffy the puppy (long-press the pet or open launcher settings). Tap the animal to pet, feed, play, or let it sleep. Facial expressions and bounce animations respond to the actions. The chosen animal is saved locally. Previous desktop, folder, START menu, favorite and settings functions remain present.

Tap NEW FOLDER to name a folder. Open MY APPS and long-press any app to add it to the desktop, a folder, or Favorites. Hold a desktop icon and drag it onto another slot to move/swap, onto a folder to file it, or onto a page arrow to move to another page. Tap a desktop folder to open and manage its apps, rename it, or delete it (without uninstalling apps). The desktop positions and preferences are persisted locally.
